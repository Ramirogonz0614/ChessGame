package com.sun.codemodel.internal;

public class JLabel {

}
